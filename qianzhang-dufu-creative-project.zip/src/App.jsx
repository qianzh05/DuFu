import AutumnStirrings from './AutumnStirrings'

function App() {
  return <AutumnStirrings />
}

export default App